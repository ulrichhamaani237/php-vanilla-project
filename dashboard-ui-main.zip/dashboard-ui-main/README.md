### Live Demo

[Githr Dashboard - Vercel](https://githr.vercel.app/)

### Preview

![Githr - Dashboard UI](public/preview.png)
